# Handoff: Context Intelligence Marketing Website

## Overview
A single-page marketing site for **Context Intelligence**, an independent executive advisory firm. The site was revised from an existing design to be more commercially compelling: it states the business problem clearly, quantifies the cost of "lost organizational intelligence," explains what the firm does, and drives visitors to two conversion actions — a 5-minute self-assessment and a scheduled executive strategy session.

**Important brand-separation note for the developer:** Context Intelligence is a strategy/advisory firm, not a software product. Do not add product screenshots, app UI, or language implying the firm owns software (e.g. "our platform records your calls"). It advises on strategy, architecture, governance, and adoption — technology may support the work but is never presented as proprietary to Context Intelligence.

## About the Design Files
The files in `design-files/` are **design references authored as HTML prototypes** (Claude "Design Components" — `.dc.html`), not production code to copy directly. They demonstrate the intended layout, copy, spacing, and visual treatment section-by-section. Your task is to **recreate this design in your target stack** (React/Next.js, Vue, plain static site, etc. — pick whatever suits the deployment target, e.g. Vercel/Netlify for a marketing site) using standard web technologies. Treat the HTML as the spec for markup structure and inline styles as the spec for exact CSS values — but implement it with your own components/build tooling, not by serving these files verbatim (they depend on a proprietary runtime script (`support.js`) that only exists in the design tool and will not run standalone).

## Fidelity
**High-fidelity.** Every section has final copy, exact colors (as CSS custom properties, see `design-tokens/`), exact typography, and exact spacing values written inline in the HTML. Recreate pixel-for-pixel.

## Page Structure (single page, in order)
1. **Header** — sticky nav, logo, 5 links (Intelligence / AI Blueprint / Independence / Assessment / About), "Schedule" button. Blurred translucent navy background on scroll.
2. **Hero** — eyebrow "A New Management Discipline," large serif headline ("Your organization is losing the intelligence it already paid to create"), two-paragraph subhead, primary CTA ("Take the 5-Minute Intelligence Assessment") + secondary link ("Explore the methodology"). Faint knowledge-graph network illustration behind the text, masked/faded into the background.
3. **Problem** — "You have probably seen the symptoms already." Three-column card grid: Decisions slow down / Knowledge disappears / AI underperforms. Closing italic serif pull-quote.
4. **Cost** — "Lost intelligence becomes an operating cost." Two-column: body copy on left, stacked list of 8 consequences on right (list rows on hairline dividers).
5. **Asset** (`#asset`) — "These are not isolated problems. They are symptoms of unmanaged Organizational Intelligence." Two-column: body copy + a numbered list of 5 "strategic assets" (People, Capital, Technology, Data, Organizational Intelligence — the 5th highlighted gold). Closing serif line: "AI is not the competitive advantage. The organizational context behind it is."
6. **WhatWeDo** — "We help leadership teams make their organization's intelligence usable." Four-column card grid: Diagnose intelligence gaps / Design the future-state architecture / Prioritize transformation opportunities / Guide execution and adoption.
7. **Methodology** (`#methodology`) — "Capture. Connect. Activate. Learn." Four-column card grid, one per stage.
8. **Pathways** (`#pathways`, containing anchors `#pathway-ai` and `#pathway-bi`) — "Two pathways. One intelligence foundation." Two unequal-width cards side by side: primary gold-accented "AI Transformation Blueprint" card (larger, 9-item checklist, primary CTA) and secondary blue-accented "Business Independence Blueprint" card (smaller, 4-item checklist, blue CTA).
9. **Process** (`#process`) — "From fragmented knowledge to an operating capability." Five-column process: Discover / Diagnose / Design / Activate / Evolve, each with a body line plus a small-caps "Output:" line.
10. **BeforeAfter** — "What changes when intelligence becomes usable." **This is the one light/neutral section on the page** — background `var(--paper-50)` (#F7F4EC) instead of navy, white cards, dark navy text. Three cards: Executive decisions / Institutional knowledge / AI transformation, each with a red "Before" line and a green "After" line.
11. **About** (`#about`) — founder section. Circular headshot (see `assets/troy-mott.png`) at left, bio copy at right for "Troy Mott, Founder & Executive Advisor, Context Intelligence."
12. **Assessment** (`#assessment`) — "How much organizational intelligence is your company losing?" Two-column: description + 5 assessed areas + primary CTA on left; a 3-level maturity scorecard (Fragmented / Connected / Activated, colored red/gold/green) on right.
13. **ContactFooter** (`#contact`) — closing CTA ("Find where your organization is losing intelligence before investing in more technology") with primary + secondary buttons, then a 4-column footer (logo+tagline, Discipline links, Engagement links, Firm links) and a copyright bar with the tagline "Capture. Connect. Activate. Advantage."

A modal dialog (triggered by every "Schedule"/CTA button) collects Name, Work email, Organization before submission — see the `<x-import ... Dialog>` block at the bottom of `ContextIntelligenceSite.dc.html`.

## Interactions & Behavior
- All in-page nav links are anchor scrolls (`#asset`, `#methodology`, `#pathways`, `#pathway-ai`, `#pathway-bi`, `#process`, `#about`, `#assessment`, `#contact`).
- Every primary/secondary CTA button opens the same lead-capture dialog (name, email, organization, submit). No backend wiring exists yet — the developer should wire this to the real lead-capture system (CRM form, email, etc.).
- Header is `position: sticky; top: 0` with `backdrop-filter: blur(14px)` over `rgba(10,15,30,0.82)`.
- No scroll-triggered animations in the current build; keep entrance motion subtle (fades/small rises, 140–380ms, `cubic-bezier(0.4,0,0.2,1)`) if you add any, per the design system's motion guidance.
- Responsive behavior was not explicitly authored for mobile — the design was built at desktop width. On mobile, stack all multi-column grids to a single column, keep the hero headline as the dominant element, and keep CTA buttons full-width and easily tappable (44px+ height, already the case for the buttons).

## State Management
- Single boolean: whether the lead-capture dialog is open (see `Component` class in `ContextIntelligenceSite.dc.html` — `state = { open: false }`).
- The dialog's form fields have no persisted state in this prototype (no validation, no submission handler) — implement real form state/validation/submission in the target codebase.

## Design Tokens
Full token files are in `design-tokens/tokens/` (`colors.css`, `typography.css`, `layout.css`, `fonts.css`, `base.css`) plus `design-tokens/styles.css` (entry point) and `design-tokens/design-system-readme.md` (full brand guide). Key values:

**Color**
- Background base: `--navy-900 #0A0F1E`; raised sections: `--navy-850 #0D1426`; deepest (footer CTA / hero vignette): `--navy-1000 #05080F`
- Primary text (warm ivory, never pure white): `--paper-50 #F7F4EC`; secondary: `--paper-300 #B4B2AC`; tertiary: `--paper-400 #8A8E9B`
- Gold accent (intelligence/CTA): `--gold-400 #D8B679`
- Blue accent (used sparingly, "Activate"/secondary pathway): `--blue-500 #2F76FF`
- Status: positive `#5FB58A`, caution `#D8B679` (gold), critical `#D9695F`
- Hairline borders: `rgba(247,244,236,0.07)`–`rgba(247,244,236,0.18)` depending on emphasis
- The one light section (BeforeAfter) uses `--paper-50 #F7F4EC` as background with near-black navy text — the only non-navy surface on the page.

**Type**
- Display/headings: **Newsreader** (serif), weight 300/400, negative letter-spacing (~-0.018em to -0.022em), often with a gold italic phrase inline
- Body/UI: **Hanken Grotesk** (sans), 1.6–1.65 line-height
- Eyebrows/labels/metadata: **IBM Plex Mono**, uppercase, ~0.1–0.14em letter-spacing
- Logo wordmark only: **Jost**, geometric caps, wide tracking
- All three body faces load from Google Fonts (see `tokens/fonts.css`) — no proprietary fonts exist.

**Spacing / Radius**
- Section vertical padding: 112px top/bottom (desktop), 32px horizontal
- Max content width: `--maxw-wide` (see `layout.css`, ~1280px)
- Card radius: 14px (`--radius-lg`)
- Buttons/badges: full pill radius

## Assets
- `assets/logo-full.png` — full logo lockup (footer)
- `assets/logo-mark.png` — C-network mark (header) — **note:** in the current prototype this asset 404s because of a relative-path mismatch (`asset-base="../../assets/"` in the Logo component call doesn't resolve inside the design tool's file structure). Point your build's asset pipeline at the correct `/assets/logo-mark.png` path and this resolves itself.
- `assets/troy-mott.png` — founder headshot, drop into the circular avatar slot in the About section.
- No other imagery is used — the design deliberately avoids stock photography, robots, circuit boards, or AI clichés. The only illustrated element is the abstract knowledge-graph network motif behind the hero (rendered via a `KnowledgeGraph` design-system component — nodes/edges, gold/blue accents — recreate as a lightweight SVG/canvas generative pattern, not a static image).

## Screenshots
`screenshots/01-full-page.png` through `12-full-page.png` are sequential scroll captures of the full page, top to bottom, in section order — use these alongside the HTML for exact visual reference.

## Files
- `design-files/ContextIntelligenceSite.dc.html` — top-level page assembly (imports every section in order + the lead-capture dialog)
- `design-files/Header.dc.html`, `Hero.dc.html`, `Problem.dc.html`, `Cost.dc.html`, `Asset.dc.html`, `WhatWeDo.dc.html`, `Methodology.dc.html`, `Pathways.dc.html`, `Process.dc.html`, `BeforeAfter.dc.html`, `About.dc.html`, `Assessment.dc.html`, `ContactFooter.dc.html` — one file per page section, in page order
- `design-tokens/` — full design-system token CSS + brand readme for exact color/type/spacing values
- `assets/` — logo and founder photo
