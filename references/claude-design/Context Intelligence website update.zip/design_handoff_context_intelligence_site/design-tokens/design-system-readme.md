# Context Intelligence — Design System

> Capture. Connect. Activate. **Advantage.**

The brand and component system for **Context Intelligence** — a category-defining
executive consulting firm helping organizations build the business context that
makes AI work. The identity is built to feel like a **premium executive strategy
publication**: intelligent, trusted, sophisticated, strategic, calm.

The thesis: *AI isn't the competitive advantage. Context Intelligence is.*

---

## Sources & provenance

This system was authored from a written brand brief plus a uploaded logo
(`uploads/ChatGPT Image Jun 29, 2026, 01_28_12 PM.png`, now in `assets/logo-full.png`).
Six reference screenshots were provided as **aesthetic register** only (Apple,
Palantir, Stripe, Anthropic, Vercel) — not brand assets. There was **no codebase
or Figma file**; component behavior and visuals are designed from the brief.

**Type substitution note:** no proprietary brand fonts exist. Faces are the chosen
brand faces, loaded from Google Fonts: **Newsreader** (editorial serif),
**Hanken Grotesk** (body/UI), **Jost** (logo wordmark — thin geometric caps),
**IBM Plex Mono** (labels/data). If you have licensed display faces you'd prefer,
send them and we'll swap the `@import` for self-hosted `@font-face`.

---

## CONTENT FUNDAMENTALS

How Context Intelligence writes.

**Voice.** Declarative and certain, never breathless. We state truths the way a
senior advisor would in a boardroom — calm confidence, no hype. Sentences are
complete and composed; the cadence is editorial, not promotional.

**Person.** "We" for the firm, "you / your enterprise" for the client. Never "I".
We speak *with* leadership, not *down* to operators.

**Casing.** Sentence case for body and headlines. **Mono UPPERCASE with wide
tracking** is reserved for eyebrows, labels, and metadata (e.g. `THE THESIS`,
`CONTEXT COVERAGE`). The wordmark is uppercase geometric caps.

**Punctuation.** No exclamation marks. Em-dashes for considered asides. Periods
in the tagline are deliberate: *Capture. Connect. Activate. Advantage.*

**Vocabulary.** Capture, connect, activate, advantage; context, knowledge,
discipline, institutional intelligence, governance, trust. We say *discipline*
and *practice*, not *platform* or *tool*. We avoid: "revolutionary",
"game-changing", "supercharged", "unlock", "leverage" (as a verb), AI buzzwords,
and robot/cyber imagery in language.

**Examples.**
- Headline: *"Models are converging. What separates the leaders is the quality of the context they bring."*
- Eyebrow: `A NEW MANAGEMENT DISCIPLINE`
- Proof: *"They didn't sell us another tool. They gave our leadership a shared discipline."*
- CTA: *"Make context your advantage."* / *"Request a briefing."*

**Emoji.** Never. Not part of the brand.

---

## VISUAL FOUNDATIONS

**Color.** Deep midnight **navy** grounds everything (`--navy-900 #0A0F1E` base,
down to `--navy-1000 #05080F` for hero vignettes). Typography is **warm ivory**
(`--paper-50 #F7F4EC`) — never pure white; the warmth is what reads as premium.
**Gold** (`--gold-400 #D8B679`) is the signature accent — it means *intelligence,
meaning, activated context*; used for eyebrows, key numbers, primary buttons, the
"Intelligence"/"Advantage" words. **Electric blue** (`--blue-500 #2F76FF`) is used
**sparingly** — it means *active AI, interaction, connection* (switches, active
graph edges, the "Activate" step). Status: positive green, caution gold, critical
muted red. Two background colors max per surface (`--navy-900` / `--navy-850`).

**Type.** A dual system. **Newsreader** (serif) carries all display and headings —
set light (300/400) and large, with negative tracking, often with a gold *italic*
phrase. **Hanken Grotesk** is body and UI at 1.62 line-height. **IBM Plex Mono**
is every eyebrow, label, metric, and metadata string. **Jost** (geometric caps,
wide-tracked) is the logo wordmark only. Display type is used sparingly and large —
the whitespace around it does the work.

**Spacing & layout.** 4px base scale, but applied *generously* — sections breathe
at 96–128px vertical padding. Reading columns cap at 720px; content at 1080–1280px.
Left-aligned editorial composition with eyebrow → headline → body rhythm.

**Backgrounds.** Flat navy, occasionally with the **knowledge-graph motif** behind
heroes at low opacity, masked with a radial gradient so it fades into the ground.
No photography, no stock imagery, no purple AI gradients, no glows except the
restrained gold/blue accent glows on interactive elements.

**The motif.** Abstract **knowledge networks** — nodes and edges where a few nodes
activate gold and a few edges pulse electric blue. This is *context becoming
intelligence*. Never literal AI: no robots, circuit boards, or brains. The logo
itself is a C formed from this network (gold above, blue below, a gold hub).

**Corners & cards.** Restrained radii (`--radius-lg 14px` for cards, pill for
buttons/badges). Cards are navy surfaces with a hairline border, a soft deep
shadow (`--shadow-md`), and a 1px lit top edge (`--shadow-inset-top`) for a
crafted feel. **Never** a colored left-border accent card.

**Borders.** Hairlines at low-opacity ivory (`--border-default` ≈ 11% ivory).
Strong borders for emphasis; gold/blue borders for accented or active states.

**Shadows.** Deep and soft, never harsh — large blur, low opacity, pure black.
Accent *glows* (gold/blue) appear only on hover/active of filled controls and the
focus ring (blue).

**Motion.** Subtle and considered. Standard ease `cubic-bezier(0.4,0,0.2,1)`;
refined deceleration `--ease-out` for entrances. Durations 140–380ms. Fades and
small rises (10–14px), never bounce or spring. Activated graph nodes breathe
slowly; edges pulse. Respects `prefers-reduced-motion`.

**Hover / press.** Hover lifts a soft glow on filled buttons and raises
interactive cards 2px with a stronger border. Press shrinks ~1.5% and settles —
quiet, physical, never flashy. Links shift one step lighter in blue.

**Transparency & blur.** Used for chrome: the sticky header and modal backdrops
use `backdrop-filter: blur()` over a translucent navy. Otherwise surfaces are solid.

**Imagery vibe.** Cool, deep, nocturnal — the palette of a late-evening boardroom.
Warm only in the ivory type and gold accents.

---

## ICONOGRAPHY

The brand uses **thin line icons** (1.6px stroke, round caps/joins, 24px grid) —
the geometric, restrained register of Lucide / Feather. They appear in product
navigation and inline affordances only; the marketing surfaces lean on type and
the graph motif rather than icons.

- **In this system:** product nav icons are authored as inline SVGs in
  `ui_kits/product/Sidebar.jsx` (overview, graph, sources, activation, governance)
  at 1.6px stroke. Match this weight and the round line-cap style for any new icon.
- **Recommended set:** [Lucide](https://lucide.dev) (CDN:
  `https://unpkg.com/lucide-static`) — same stroke weight and feel. **Flagged
  substitution:** the brand has no proprietary icon font; Lucide is the closest
  match and is what we standardize on.
- **Glyphs as icons:** simple arrows (`→ ↗`) and the gold tick rule are used as
  lightweight directional/section marks. No emoji. No unicode symbol soup.
- **Logo mark:** `assets/logo-mark.png` (the C-network) and `assets/logo-full.png`
  (full lockup) are the only raster brand assets. Use the `Logo` component to
  place them; never recolor the mark.

---

## INDEX

**Root**
- `styles.css` — global entry point (consumers link this one file). `@import`s only.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills-compatible entry for use in Claude Code.

**`tokens/`** — `fonts.css`, `colors.css`, `typography.css`, `layout.css` (spacing,
radius, shadow, motion, z-index, layout), `base.css` (reset). All reached from `styles.css`.

**`assets/`** — `logo-full.png` (lockup), `logo-mark.png` (C-network mark).

**`guidelines/`** — foundation specimen cards (Design System tab): colors (navy,
paper, gold, blue, status), type (display, body, mono), spacing (scale, radius),
brand (logo, motif, voice).

**`components/`** — reusable primitives (namespace `window.ContextIntelligenceDesignSystem_82314b`):
- `core/` — **Button**, **Card**, **Badge**, **Avatar**
- `forms/` — **Input**, **Select**, **Switch**, **Checkbox**
- `navigation/` — **Tabs**
- `feedback/` — **Tooltip**, **Dialog**
- `brand/` — **Logo**, **EyebrowLabel**, **Stat**, **KnowledgeGraph**

Each has a `.jsx`, `.d.ts` (props), `.prompt.md` (usage), and a directory `@dsCard`.

**`ui_kits/`** — full-screen recreations:
- `website/` — the marketing site (hero, thesis, capabilities, proof, CTA, footer).
- `product/` — the **Context Graph** workspace (sidebar, topbar, overview, interactive graph, sources, activation).

**`templates/`** — copyable starting points:
- `executive-deck/` — boardroom slide deck (`ExecutiveDeck.dc.html`) in the publication style.

---

## Quick start

In any HTML, link the tokens and load the bundle:

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, Card, EyebrowLabel, KnowledgeGraph } = window.ContextIntelligenceDesignSystem_82314b;
</script>
```

Compose with eyebrow → serif headline → body. Gold for intelligence, blue for
active connection, ivory for everything else, on navy. Let it breathe.
